from PyQt5.QtWidgets import QMainWindow, QApplication, QLabel, QLineEdit, QPushButton
from PyQt5.uic import loadUi
import sys
from Media import main_rc

class Window(QMainWindow):
    def __init__(self):
        super(Window, self).__init__()
        self.tup_id = None
        self.password = None

        loadUi('Register_window.ui', self)

        self.title_label = self.findChild(QLabel, 'title_label')
        self.enter_tup_id_label = self.findChild(QLabel, 'enter_tup_id_label')
        self.tup_id_line_edit = self.findChild(QLineEdit, 'tup_id_line_edit')
        self.enter_password_label = self.findChild(QLabel, 'enter_password_label')
        self.password_line_edit = self.findChild(QLineEdit, 'password_line_edit')
        self.confirm_password_label = self.findChild(QLabel, 'confirm_password_Label')
        self.confirm_password_line_edit = self.findChild(QLineEdit, 'confirm_password_line_edit')
        self.register_button = self.findChild(QPushButton, 'register_button')

        self.setupUi()

    def setupUi(self):
        self.register_button.clicked.connect(self.register)

    def register(self):
        self.tup_id = self.tup_id_line_edit.text()
        self.password = self.password_line_edit.text()
        
        if self.password != self.confirm_password_line_edit.text():
            self.tup_id = None
            self.password = None

            self.password_line_edit.setText('')

        self.hide()

        

def main():
    app = QApplication(sys.argv)
    window = Window()
    window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()