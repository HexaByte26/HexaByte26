import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QLabel, QCalendarWidget, QLineEdit, QMessageBox
from PyQt5.QtCore import Qt, QDate
from Media2 import main_rc

class Calendar(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("Calendar.ui", self)  # Change filename as needed

        self.calendar = self.findChild(QCalendarWidget, "calendarWidget")
        self.notes_text = self.findChild(QLineEdit, "notes_event_input")
        self.save_button = self.findChild(QPushButton, "save_note_button")
        self.delete_button = self.findChild(QPushButton, "delete_note")
        

        self.notes_data = {}  # Dictionary to store notes per date

        self.calendar.selectionChanged.connect(self.load_note)
        self.save_button.clicked.connect(self.save_note)
        self.delete_button.clicked.connect(self.delete_note_action)

        self.load_note()  # Load note for initial selected date

    def load_note(self):
        selected_date = self.calendar.selectedDate()
        date_str = selected_date.toString(Qt.ISODate)
        note = self.notes_data.get(date_str, "")
        self.notes_text.setText(note)

    def save_note(self):
        selected_date = self.calendar.selectedDate()
        date_str = selected_date.toString(Qt.ISODate)
        note = self.notes_text.text().strip()

        if note:
            self.notes_data[date_str] = note
            QMessageBox.information(self, "Saved", f"Event for {selected_date.toString()} saved.")
        else:
            self.notes_data.pop(date_str, None)
            self.notes_text.clear()
            QMessageBox.information(self, "Deleted", f"Event for {selected_date.toString()} deleted.")

        self.statusBar().showMessage(f"Note for {date_str} saved.", 3000)

    def delete_note_action(self):
        selected_date = self.calendar.selectedDate()
        date_str = selected_date.toString(Qt.ISODate)
        if date_str in self.notes_data:
            del self.notes_data[date_str]
            self.notes_text.clear()
            QMessageBox.information(self, "Deleted", f"Event for {selected_date.toString()} permanently deleted.")
        else:
            QMessageBox.information(self, "No Note", f"No note exists for {selected_date.toString()} to delete.")


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = Calendar()
    window.show()
    sys.exit(app.exec_())
