from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5.uic import loadUi
import sys
from Media2 import main_rc

class Window(QMainWindow):
    def __init__(self):
        super(Window, self).__init__()

        loadUi('Add_Announcement.ui', self)

def main():
    app = QApplication(sys.argv)
    window = Window()
    window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()