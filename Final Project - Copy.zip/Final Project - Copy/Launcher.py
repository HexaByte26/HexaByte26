import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QCalendarWidget, QPushButton, QMessageBox, QLineEdit
from PyQt5.QtCore import Qt
from PyQt5.uic import loadUi
from Media import main_rc
from Media2 import main_rc


class LoginWindow(QMainWindow):
    def __init__(self):
        super(LoginWindow,self).__init__()
        loadUi('login_window.ui', self)  # Make sure to use the correct path to your .ui file
        self.show()
        
        self.login_button.clicked.connect(self.login_button_clicked)
    
    def login_button_clicked(self):
        # Get the text from the username and password fields
        username = self.Username.text()
        password = self.Password.text()
        
            # HAVE TO USE JSON FOR USER DATABASE
        user_db = {"Moya0825": "0825",
        "admin": "password",
        "user": "1234"
            }    
            
        if username in user_db and user_db[username] == password:
            print("Login successful")
            # Here you can add code to open the main application window
        else:
            print("Invalid credentials")

        self.hide()
        news_tab_window.show()

class NewsTab(QMainWindow):
    def __init__(self):
        super(NewsTab, self).__init__()

        loadUi('NEWS-TAB.ui', self)

        self.announcements_button = self.findChild(QPushButton, 'announcements_button')
        self.calendar_button = self.findChild(QPushButton, 'calendar_button')

        self.set_up_ui()

    def set_up_ui(self):
        self.announcements_button.clicked.connect(self.tab_clicked)
        self.calendar_button.clicked.connect(self.tab_clicked)

    def tab_clicked(self):
        sender_button = self.sender()
        if sender_button.text() == 'ANNOUNCEMENTS':
            add_announcemenets_window.show()
        elif sender_button.text() == 'CALENDAR':
            calendar_window.show()

class AddAnnouncements(QMainWindow):
    def __init__(self):
        super(AddAnnouncements, self).__init__()

        loadUi('Add_Announcement.ui', self)

class Calendar(QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi("Calendar.ui", self)  # Change filename as needed

        self.calendar = self.findChild(QCalendarWidget, "calendarWidget")
        self.notes_text = self.findChild(QLineEdit, "notes_event_input")
        self.save_button = self.findChild(QPushButton, "save_note_button")
        self.delete_button = self.findChild(QPushButton, "delete_note")
        

        self.notes_data = {}  # Dictionary to store notes per date

        self.calendar.selectionChanged.connect(self.load_note)
        self.save_button.clicked.connect(self.save_note)
        self.delete_button.clicked.connect(self.delete_note_action)

        self.load_note()  # Load note for initial selected date

    def load_note(self):
        selected_date = self.calendar.selectedDate()
        date_str = selected_date.toString(Qt.ISODate)
        note = self.notes_data.get(date_str, "")
        self.notes_text.setText(note)

    def save_note(self):
        selected_date = self.calendar.selectedDate()
        date_str = selected_date.toString(Qt.ISODate)
        note = self.notes_text.text().strip()

        if note:
            self.notes_data[date_str] = note
            QMessageBox.information(self, "Saved", f"Event for {selected_date.toString()} saved.")
        else:
            self.notes_data.pop(date_str, None)
            self.notes_text.clear()
            QMessageBox.information(self, "Deleted", f"Event for {selected_date.toString()} deleted.")

        self.statusBar().showMessage(f"Note for {date_str} saved.", 3000)

    def delete_note_action(self):
        selected_date = self.calendar.selectedDate()
        date_str = selected_date.toString(Qt.ISODate)
        if date_str in self.notes_data:
            del self.notes_data[date_str]
            self.notes_text.clear()
            QMessageBox.information(self, "Deleted", f"Event for {selected_date.toString()} permanently deleted.")
        else:
            QMessageBox.information(self, "No Note", f"No note exists for {selected_date.toString()} to delete.")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    login_window = LoginWindow()
    news_tab_window = NewsTab()
    add_announcemenets_window = AddAnnouncements()
    calendar_window = Calendar()

    sys.exit(app.exec_())
